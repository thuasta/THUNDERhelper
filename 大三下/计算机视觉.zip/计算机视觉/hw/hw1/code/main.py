import numpy as np

from utils import *
from color_editor import color_twist

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    plot2_1()
    plot2_3()
    color_twist()
    plot3_1()
    Histogram_equalization()
    histogram_equalization_pro()
